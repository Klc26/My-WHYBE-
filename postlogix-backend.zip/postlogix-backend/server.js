const app = require('./src/app');
const config = require('./src/config');

app.listen(config.port, () => {
  console.log(`POSTLOGIX AI backend running on http://localhost:${config.port}`);
  console.log(`AI provider: ${config.ai.provider}`);
});
