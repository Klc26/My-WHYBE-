# POSTLOGIX AI — Backend

Node.js/Express backend for the POSTLOGIX AI parcel-logistics frontend. It replaces
the hardcoded browser JS from the prototype with real API endpoints, a small
post-office dataset, optional LLM-based address parsing, and stubs for the
other AI feature cards (address fixer, delivery-risk score, pickup suggestion,
voice intake).

## 1. Setup

```bash
cd postlogix-backend
npm install
cp .env.example .env
npm start          # or: npm run dev  (auto-restarts on file changes)
```

Server runs at `http://localhost:5000` by default. Health check:
`GET http://localhost:5000/api/health`

### Connecting a real AI model (optional)
By default, address parsing uses the same rule-based city/state matching the
prototype used (`src/utils/addressProcessor.js`). To use a real LLM instead,
set in `.env`:

```
AI_PROVIDER=gemini            # or: openai
GEMINI_API_KEY=your-key-here
```

The API key stays server-side — never expose it in frontend JS, which was the
whole point of building this backend (see the original README's note).

## 2. Project layout

```
postlogix-backend/
├── server.js                     entry point
├── src/
│   ├── app.js                    express app: middleware + routes
│   ├── config/index.js           env config
│   ├── data/
│   │   ├── postOffices.json      seed post-office dataset (15 cities)
│   │   └── parcels.json          runtime parcel storage (JSON file "DB")
│   ├── utils/
│   │   ├── validators.js         payload validation
│   │   ├── addressProcessor.js   rule-based + optional Gemini/OpenAI extraction
│   │   ├── postOfficeMatcher.js  PIN/city/state matching logic
│   │   └── jsonStore.js          tiny file-backed JSON store (swap for a real DB later)
│   ├── controllers/              parcel / ai / postOffice controllers
│   ├── routes/                   route definitions
│   └── middleware/errorHandler.js
└── frontend-integrated/
    └── index.html                your original frontend, wired up to call this API
```

## 3. API reference

### Parcels — core 3-stage workflow
| Method | Route | Body | Description |
|---|---|---|---|
| POST | `/api/parcels/validate` | `{parcelId, address, pin, service?}` | Stage 1: field/PIN validation |
| POST | `/api/parcels/process` | `{address, ...}` | Stage 2: extracts city/state/landmark |
| POST | `/api/parcels/identify` | `{parcelId, address, pin, service?}` | Stage 3: matches a post office |
| POST | `/api/parcels` | full payload | Runs all 3 stages and **saves** a parcel record |
| GET | `/api/parcels` | — | List saved parcels |
| GET | `/api/parcels/:id` | — | Get one parcel |
| PATCH | `/api/parcels/:id` | `{status?, sender?, receiver?, service?}` | Update a parcel |
| DELETE | `/api/parcels/:id` | — | Delete a parcel |

### AI feature endpoints (matching the frontend's feature cards)
| Method | Route | Body | Description |
|---|---|---|---|
| POST | `/api/ai/fix-address` | `{address}` | Cleans/normalizes an address, appends detected city/state |
| POST | `/api/ai/risk` | `{address, pin, attempts?}` | Heuristic failed-delivery risk score (0–100) |
| POST | `/api/ai/pickup-suggestion` | `{address, pin}` | Suggests a primary + alternate pickup post offices |
| POST | `/api/ai/voice-intake` | `{transcript, lang?}` | Runs already-transcribed speech through address extraction |
| GET | `/api/ai/known-localities` | — | Debug: list of localities the rule-based fallback recognizes |

### Post offices
| Method | Route | Description |
|---|---|---|
| GET | `/api/postoffices` | List the seed dataset |
| GET | `/api/postoffices/:pin` | Look up by PIN code |

## 4. Wiring up the frontend

`frontend-integrated/index.html` is your original file with the 3 workflow
functions (`validate`, `processAI`, `identify`) rewritten to call the API
above instead of the inline demo logic. Open it directly in a browser (or
serve it with any static server) while the backend is running — it defaults
to `http://localhost:5000/api`. To point it at a deployed backend, set
`window.POSTLOGIX_API_BASE` before the script runs, e.g.:

```html
<script>window.POSTLOGIX_API_BASE = 'https://your-backend.example.com/api';</script>
```

## 5. Notes / next steps
- Parcel storage is a flat JSON file (`src/data/parcels.json`) — fine for a
  hackathon demo, swap `src/utils/jsonStore.js` for Postgres/Mongo for production.
- CORS origins are configurable via `CORS_ORIGIN` in `.env`.
- Rate limiting (120 req/min) and `helmet` security headers are enabled by default.
