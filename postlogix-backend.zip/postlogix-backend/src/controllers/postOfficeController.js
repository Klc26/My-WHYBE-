const { findByPin, listAll } = require('../utils/postOfficeMatcher');

// GET /api/postoffices
function list(req, res) {
  return res.json(listAll());
}

// GET /api/postoffices/:pin
function byPin(req, res) {
  const matches = findByPin(req.params.pin);
  if (!matches.length) return res.status(404).json({ error: 'No post office found for that PIN.' });
  return res.json(matches);
}

module.exports = { list, byPin };
