const path = require('path');
const { nanoid } = require('nanoid');
const JsonStore = require('../utils/jsonStore');
const { validateParcelPayload } = require('../utils/validators');
const { processAddress } = require('../utils/addressProcessor');
const { identifyPostOffice } = require('../utils/postOfficeMatcher');

const store = new JsonStore(path.join(__dirname, '..', 'data', 'parcels.json'));

// POST /api/parcels/validate
function validate(req, res) {
  const { valid, errors } = validateParcelPayload(req.body);
  if (!valid) {
    return res.status(400).json({ valid: false, errors });
  }
  return res.json({ valid: true, message: 'Validation passed — required parcel and address fields look complete.' });
}

// POST /api/parcels/process
async function process(req, res) {
  const { valid, errors } = validateParcelPayload(req.body);
  if (!valid) return res.status(400).json({ valid: false, errors });

  const extracted = await processAddress(req.body.address);
  return res.json({ valid: true, extracted });
}

// POST /api/parcels/identify
async function identify(req, res) {
  const { valid, errors } = validateParcelPayload(req.body);
  if (!valid) return res.status(400).json({ valid: false, errors });

  const { address, pin } = req.body;
  const extracted = await processAddress(address);
  const { office, matchType } = identifyPostOffice({
    pin: String(pin).trim(),
    city: extracted.city,
    state: extracted.state,
    addressText: address,
  });

  return res.json({
    valid: true,
    extracted,
    recommendedOffice: office,
    matchType,
    action: req.body.service || 'Standard Delivery',
  });
}

// POST /api/parcels  (runs the full 3-stage workflow and saves a record)
async function createParcel(req, res) {
  const { valid, errors } = validateParcelPayload(req.body);
  if (!valid) return res.status(400).json({ valid: false, errors });

  const { parcelId, sender, receiver, address, pin, service, lang } = req.body;
  const extracted = await processAddress(address);
  const { office, matchType } = identifyPostOffice({
    pin: String(pin).trim(),
    city: extracted.city,
    state: extracted.state,
    addressText: address,
  });

  const record = {
    id: nanoid(10),
    parcelId,
    sender: sender || null,
    receiver: receiver || null,
    address,
    pin,
    service: service || 'Standard Delivery',
    language: lang || 'English',
    extracted,
    recommendedOffice: office,
    matchType,
    status: 'processed',
    createdAt: new Date().toISOString(),
  };

  store.insert(record);
  return res.status(201).json(record);
}

// GET /api/parcels
function listParcels(req, res) {
  return res.json(store.all());
}

// GET /api/parcels/:id
function getParcel(req, res) {
  const record = store.findById(req.params.id);
  if (!record) return res.status(404).json({ error: 'Parcel not found.' });
  return res.json(record);
}

// PATCH /api/parcels/:id  (e.g. update status: dispatched / delivered / failed)
function updateParcel(req, res) {
  const allowed = ['status', 'sender', 'receiver', 'service'];
  const patch = {};
  allowed.forEach((k) => {
    if (req.body[k] !== undefined) patch[k] = req.body[k];
  });

  const updated = store.update(req.params.id, patch);
  if (!updated) return res.status(404).json({ error: 'Parcel not found.' });
  return res.json(updated);
}

// DELETE /api/parcels/:id
function deleteParcel(req, res) {
  const removed = store.remove(req.params.id);
  if (!removed) return res.status(404).json({ error: 'Parcel not found.' });
  return res.status(204).send();
}

module.exports = {
  validate,
  process,
  identify,
  createParcel,
  listParcels,
  getParcel,
  updateParcel,
  deleteParcel,
};
