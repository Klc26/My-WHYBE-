const { processAddress, KNOWN_LOCALITIES } = require('../utils/addressProcessor');
const { identifyPostOffice, listAll } = require('../utils/postOfficeMatcher');

// POST /api/ai/fix-address  { address }
// Cleans up whitespace/casing and appends the detected city/state if missing.
async function fixAddress(req, res) {
  const { address } = req.body;
  if (!address || !String(address).trim()) {
    return res.status(400).json({ error: 'address is required.' });
  }

  const cleaned = address
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/,\s*,/g, ',')
    .replace(/^,|,$/g, '');

  const extracted = await processAddress(cleaned);
  let fixed = cleaned;
  const lower = cleaned.toLowerCase();

  if (extracted.city !== 'Unknown' && !lower.includes(extracted.city.toLowerCase())) {
    fixed = `${fixed}, ${extracted.city}`;
  }
  if (extracted.state !== 'Unknown' && !lower.includes(extracted.state.toLowerCase())) {
    fixed = `${fixed}, ${extracted.state}`;
  }

  return res.json({ original: address, fixed, extracted });
}

// POST /api/ai/risk  { address, pin, attempts }
// Simple heuristic failed-delivery risk score (0-100) with a suggested action.
function riskScore(req, res) {
  const { address = '', pin = '', attempts = 0 } = req.body;
  let score = 10;
  const text = address.toLowerCase();

  if (!/^\d{6}$/.test(String(pin).trim())) score += 25;
  if (!/near|opp|behind|landmark/.test(text)) score += 10;
  if (text.trim().split(/\s+/).length < 4) score += 20; // too short/vague
  score += Math.min(Number(attempts) || 0, 3) * 15;

  score = Math.min(score, 100);
  const level = score >= 60 ? 'High' : score >= 30 ? 'Medium' : 'Low';
  const suggestion =
    level === 'High'
      ? 'Recommend pickup at post office or contact recipient to confirm address before dispatch.'
      : level === 'Medium'
      ? 'Consider adding a landmark or phone verification before dispatch.'
      : 'Proceed with standard delivery.';

  return res.json({ score, level, suggestion });
}

// POST /api/ai/pickup-suggestion  { address, pin }
// Suggests the nearest 1-3 post offices as pickup points.
async function pickupSuggestion(req, res) {
  const { address = '', pin = '' } = req.body;
  const extracted = await processAddress(address);
  const { office } = identifyPostOffice({
    pin: String(pin).trim(),
    city: extracted.city,
    state: extracted.state,
    addressText: address,
  });

  const allOffices = listAll();
  const sameState = allOffices.filter((po) => po.state === extracted.state && po.id !== office.id);

  return res.json({
    primary: office,
    alternates: sameState.slice(0, 2),
  });
}

// POST /api/ai/voice-intake  { transcript, lang }
// Stub for a voice-assistant flow: accepts already-transcribed text
// (do speech-to-text on the client or via a provider before calling this)
// and runs it through the same address extraction pipeline.
async function voiceIntake(req, res) {
  const { transcript, lang = 'English' } = req.body;
  if (!transcript || !String(transcript).trim()) {
    return res.status(400).json({ error: 'transcript is required.' });
  }

  const extracted = await processAddress(transcript);
  return res.json({
    transcript,
    language: lang,
    extracted,
    note:
      'This endpoint expects already-transcribed text. Wire up a speech-to-text provider (e.g. Web Speech API on the client, or Google Speech-to-Text) to feed it live audio.',
  });
}

// GET /api/ai/known-localities — small helper for debugging the rule-based fallback
function knownLocalities(req, res) {
  return res.json(KNOWN_LOCALITIES);
}

module.exports = { fixAddress, riskScore, pickupSuggestion, voiceIntake, knownLocalities };
