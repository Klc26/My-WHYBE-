const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/postOfficeController');

router.get('/', ctrl.list);
router.get('/:pin', ctrl.byPin);

module.exports = router;
