const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/aiController');

router.post('/fix-address', ctrl.fixAddress);
router.post('/risk', ctrl.riskScore);
router.post('/pickup-suggestion', ctrl.pickupSuggestion);
router.post('/voice-intake', ctrl.voiceIntake);
router.get('/known-localities', ctrl.knownLocalities);

module.exports = router;
