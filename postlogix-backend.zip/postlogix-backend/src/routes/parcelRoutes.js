const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/parcelController');

router.post('/validate', ctrl.validate);
router.post('/process', ctrl.process);
router.post('/identify', ctrl.identify);

router.post('/', ctrl.createParcel);
router.get('/', ctrl.listParcels);
router.get('/:id', ctrl.getParcel);
router.patch('/:id', ctrl.updateParcel);
router.delete('/:id', ctrl.deleteParcel);

module.exports = router;
