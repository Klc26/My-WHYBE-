const PIN_REGEX = /^\d{6}$/;

const VALID_SERVICES = [
  'Standard Delivery',
  'Speed Post',
  'Registered Post',
  'Pickup at Post Office',
];

/**
 * Validates the core parcel/address payload.
 * Returns { valid: boolean, errors: string[] }
 */
function validateParcelPayload(body = {}) {
  const errors = [];
  const { parcelId, address, pin, service } = body;

  if (!parcelId || !String(parcelId).trim()) {
    errors.push('Parcel ID is required.');
  }
  if (!address || !String(address).trim()) {
    errors.push('Delivery address is required.');
  }
  if (!pin || !String(pin).trim()) {
    errors.push('PIN code is required.');
  } else if (!PIN_REGEX.test(String(pin).trim())) {
    errors.push('PIN code must contain exactly 6 digits.');
  }
  if (service && !VALID_SERVICES.includes(service)) {
    errors.push(`Service must be one of: ${VALID_SERVICES.join(', ')}.`);
  }

  return { valid: errors.length === 0, errors };
}

module.exports = { validateParcelPayload, PIN_REGEX, VALID_SERVICES };
