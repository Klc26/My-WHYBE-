const postOffices = require('../data/postOffices.json');

/**
 * Finds the best-matching post office for a given PIN + processed address.
 * Priority: exact PIN match -> city match -> state match -> generic fallback.
 */
function identifyPostOffice({ pin, city, state, addressText = '' }) {
  const text = addressText.toLowerCase();

  let match = postOffices.find((po) => po.pin === pin);
  let matchType = match ? 'PIN + Location' : null;

  if (!match && city && city !== 'Unknown') {
    match = postOffices.find((po) => po.city.toLowerCase() === city.toLowerCase());
    if (match) matchType = 'City match';
  }

  if (!match) {
    match = postOffices.find((po) => text.includes(po.city.toLowerCase()));
    if (match) matchType = 'Address text match';
  }

  if (!match && state && state !== 'Unknown') {
    match = postOffices.find((po) => po.state.toLowerCase() === state.toLowerCase());
    if (match) matchType = 'State match (nearest hub)';
  }

  if (!match) {
    return {
      office: {
        id: null,
        name: 'Local Delivery Post Office',
        address: 'Recommended facility based on submitted location',
        pin: pin || 'Unknown',
      },
      matchType: 'No confident match — manual routing recommended',
    };
  }

  return { office: match, matchType };
}

function findByPin(pin) {
  return postOffices.filter((po) => po.pin === pin);
}

function listAll() {
  return postOffices;
}

module.exports = { identifyPostOffice, findByPin, listAll };
