const config = require('../config');

// Same known-locality lookup the frontend prototype used, extended a bit.
const KNOWN_LOCALITIES = [
  { keyword: 'gandhinagar', city: 'Gandhinagar', state: 'Gujarat' },
  { keyword: 'ahmedabad', city: 'Ahmedabad', state: 'Gujarat' },
  { keyword: 'surat', city: 'Surat', state: 'Gujarat' },
  { keyword: 'vadodara', city: 'Vadodara', state: 'Gujarat' },
  { keyword: 'patna', city: 'Patna', state: 'Bihar' },
  { keyword: 'delhi', city: 'New Delhi', state: 'Delhi' },
  { keyword: 'mumbai', city: 'Mumbai', state: 'Maharashtra' },
  { keyword: 'bengaluru', city: 'Bengaluru', state: 'Karnataka' },
  { keyword: 'bangalore', city: 'Bengaluru', state: 'Karnataka' },
  { keyword: 'kolkata', city: 'Kolkata', state: 'West Bengal' },
  { keyword: 'chennai', city: 'Chennai', state: 'Tamil Nadu' },
  { keyword: 'hyderabad', city: 'Hyderabad', state: 'Telangana' },
  { keyword: 'jaipur', city: 'Jaipur', state: 'Rajasthan' },
  { keyword: 'lucknow', city: 'Lucknow', state: 'Uttar Pradesh' },
  { keyword: 'pune', city: 'Pune', state: 'Maharashtra' },
  { keyword: 'bhopal', city: 'Bhopal', state: 'Madhya Pradesh' },
];

function ruleBasedExtract(addressText = '') {
  const t = addressText.toLowerCase();
  const found = KNOWN_LOCALITIES.find((l) => t.includes(l.keyword));

  // crude landmark guess: text after "near"/"opp"/"behind"
  const landmarkMatch = t.match(/(?:near|opp\.?|behind)\s+([a-z0-9\s]{3,40})/i);
  const landmark = landmarkMatch ? landmarkMatch[1].trim() : null;

  return {
    city: found ? found.city : 'Unknown',
    state: found ? found.state : 'Unknown',
    landmark,
    source: 'rule-based',
    confidence: found ? 0.7 : 0.2,
  };
}

async function geminiExtract(addressText) {
  const { apiKey, model } = config.ai.gemini;
  const prompt = `Extract the city, state and any landmark from this Indian delivery address. Respond ONLY with compact JSON: {"city": "...", "state": "...", "landmark": "..."}. Address: """${addressText}"""`;

  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
      }),
    }
  );

  if (!res.ok) throw new Error(`Gemini API error: ${res.status}`);
  const data = await res.json();
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
  const clean = text.replace(/```json|```/g, '').trim();
  const parsed = JSON.parse(clean);
  return { ...parsed, source: 'gemini', confidence: 0.9 };
}

async function openaiExtract(addressText) {
  const { apiKey, model } = config.ai.openai;
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages: [
        {
          role: 'system',
          content:
            'Extract city, state and landmark from Indian delivery addresses. Respond ONLY with compact JSON: {"city": "...", "state": "...", "landmark": "..."}',
        },
        { role: 'user', content: addressText },
      ],
      temperature: 0,
    }),
  });

  if (!res.ok) throw new Error(`OpenAI API error: ${res.status}`);
  const data = await res.json();
  const text = data?.choices?.[0]?.message?.content || '{}';
  const clean = text.replace(/```json|```/g, '').trim();
  const parsed = JSON.parse(clean);
  return { ...parsed, source: 'openai', confidence: 0.9 };
}

/**
 * Extracts city/state/landmark from free-text address.
 * Uses Gemini/OpenAI when AI_PROVIDER + key are configured, otherwise
 * falls back to the same rule-based matching the frontend prototype used.
 */
async function processAddress(addressText = '') {
  const provider = config.ai.provider;

  try {
    if (provider === 'gemini' && config.ai.gemini.apiKey) {
      return await geminiExtract(addressText);
    }
    if (provider === 'openai' && config.ai.openai.apiKey) {
      return await openaiExtract(addressText);
    }
  } catch (err) {
    // Fall through to rule-based extraction on any AI failure.
    console.error('AI address processing failed, falling back:', err.message);
  }

  return ruleBasedExtract(addressText);
}

module.exports = { processAddress, ruleBasedExtract, KNOWN_LOCALITIES };
