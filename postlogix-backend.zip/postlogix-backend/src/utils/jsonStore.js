const fs = require('fs');
const path = require('path');

/**
 * Minimal file-backed JSON array store.
 * Good enough for a hackathon/prototype backend. Swap this out for a real
 * database (Postgres/Mongo) by re-implementing the same four methods.
 */
class JsonStore {
  constructor(filePath) {
    this.filePath = filePath;
    this._ensureFile();
  }

  _ensureFile() {
    const dir = path.dirname(this.filePath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(this.filePath)) {
      fs.writeFileSync(this.filePath, '[]', 'utf8');
    }
  }

  _readAll() {
    const raw = fs.readFileSync(this.filePath, 'utf8') || '[]';
    try {
      return JSON.parse(raw);
    } catch (err) {
      return [];
    }
  }

  _writeAll(records) {
    fs.writeFileSync(this.filePath, JSON.stringify(records, null, 2), 'utf8');
  }

  all() {
    return this._readAll();
  }

  findById(id) {
    return this._readAll().find((r) => r.id === id) || null;
  }

  insert(record) {
    const records = this._readAll();
    records.unshift(record);
    this._writeAll(records);
    return record;
  }

  update(id, patch) {
    const records = this._readAll();
    const idx = records.findIndex((r) => r.id === id);
    if (idx === -1) return null;
    records[idx] = { ...records[idx], ...patch };
    this._writeAll(records);
    return records[idx];
  }

  remove(id) {
    const records = this._readAll();
    const next = records.filter((r) => r.id !== id);
    this._writeAll(next);
    return next.length !== records.length;
  }
}

module.exports = JsonStore;
