require('dotenv').config();

const parseOrigins = (value) => {
  if (!value) return ['*'];
  return value.split(',').map((s) => s.trim()).filter(Boolean);
};

module.exports = {
  port: parseInt(process.env.PORT, 10) || 5000,
  nodeEnv: process.env.NODE_ENV || 'development',
  corsOrigins: parseOrigins(process.env.CORS_ORIGIN),

  ai: {
    provider: (process.env.AI_PROVIDER || 'none').toLowerCase(),
    gemini: {
      apiKey: process.env.GEMINI_API_KEY || '',
      model: process.env.GEMINI_MODEL || 'gemini-1.5-flash',
    },
    openai: {
      apiKey: process.env.OPENAI_API_KEY || '',
      model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
    },
  },
};
