const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const config = require('./config');
const parcelRoutes = require('./routes/parcelRoutes');
const aiRoutes = require('./routes/aiRoutes');
const postOfficeRoutes = require('./routes/postOfficeRoutes');
const { notFound, errorHandler } = require('./middleware/errorHandler');

const app = express();

app.use(helmet());
app.use(
  cors({
    origin: config.corsOrigins.includes('*') ? '*' : config.corsOrigins,
  })
);
app.use(express.json({ limit: '1mb' }));
app.use(morgan(config.nodeEnv === 'production' ? 'combined' : 'dev'));

// Basic rate limiting to keep the demo API from being hammered.
app.use(
  rateLimit({
    windowMs: 60 * 1000,
    max: 120,
    standardHeaders: true,
    legacyHeaders: false,
  })
);

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'postlogix-ai-backend', time: new Date().toISOString() });
});

app.use('/api/parcels', parcelRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/postoffices', postOfficeRoutes);

app.use(notFound);
app.use(errorHandler);

module.exports = app;
